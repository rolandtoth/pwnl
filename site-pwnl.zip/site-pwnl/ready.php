<?php namespace ProcessWire;

wire()->addHook('ProcessPageEdit::buildForm', function (HookEvent $event) {

    if (wire('page')->template->name != 'admin') {
        return false;
    }

    $page = wire('pages')->get(wire('input')->get->id);

    // return if page is not published
    if (!$page->isPublic()) {
        return false;
    }

    if ($page->template->name != 'newsletter') {
        return false;
    }

    $ajaxLink = $page->httpUrl . '?id=' . $page->id;

    $form = $event->return;

    wire('config')->scripts->add(wire('config')->urls->templates . 'scripts/newsletter.js');

    $testWrap = new InputfieldWrapper();
    $testWrap->attr('title', 'Test send');

    $testBtn = wire('modules')->get('InputfieldButton');
    $testBtn->attr('id+name', 'newsletter_test');
    $testBtn->attr('class', $testBtn->class);
    $testBtn->attr('value', 'Send test');
    $testBtn->attr('data-nid', $page->id);
    $testBtn->attr('data-redirect', $page->parent()->id);
    $testBtn->attr('data-target', $ajaxLink . '&test=1');

    $testWrap->add($testBtn);

    $form->insertAfter($testWrap, $form->get('newsletter_test_email'));

    // add Send newsletter button

	// get subscribers (only those who have email address)
    $subscribers = wire('pages')->find('template=subscriber, email_subscriber!=""');

    $field = wire('modules')->get('InputfieldButton');
    $field->attr('id+name', 'newsletter_send');
    $field->attr('class', $field->class);
    $field->attr('value', 'Send newsletter');

    if ($subscribers->count()) {
        $field->description = sprintf(_n("Send newsletter to %d subscriber by clicking on the button below.", "Send newsletter to %d subscribers by clicking on the button below.", $subscribers->count), $subscribers->count);
        $field->attr('data-nid', $page->id);
        $field->attr('data-redirect', $page->parent()->id);
        $field->attr('href', $ajaxLink . $page->id);
    } else {
        $field->description = 'Cannot send newsletter because there are no active subscribers.';
        $field->attr('disabled', 1);
    }

    $wrap = new InputfieldWrapper();
    $wrap->attr('class', $wrap->class . ' newsletter_send_wrap');

    $wrap->add($field);

    $form->insertAfter($wrap, $form->get('newsletter_test'));

    $event->return = $form;
});
