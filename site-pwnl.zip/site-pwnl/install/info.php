<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "ProcessWire Newsletter Tutorial", 
	'summary' => "ProcessWire newsletter tutorial site profile", 
	'screenshot' => "pwnl.png"
	);
