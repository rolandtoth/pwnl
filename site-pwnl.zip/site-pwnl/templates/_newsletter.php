<?php namespace ProcessWire;

$p = $this->modules->get('ProcessPageList');
$p->set('id', $pages->get('path=/newsletters/')->id); // the parent page
return $p->execute();
