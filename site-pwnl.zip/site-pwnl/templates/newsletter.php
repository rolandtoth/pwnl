<?php namespace ProcessWire;

// initialize Emogrifier
require_once wire('config')->paths->root . 'site/vendor/autoload.php';
$emogrifier = new \Pelago\Emogrifier();
$css = file_get_contents(wire('config')->paths->templates . 'styles/newsletter.css');

// set up variables to pass to _newsletter-content.php
$homepage = wire('pages')->get(1);
$email = 'cheers@pwtimes.com';
$logo = $homepage->featured_image->height(40);
$images = $homepage->httpUrl . 'site/templates/images/';

$contactData = array();
$contactData[] = '00 12345 678';
$contactData[] = '<a href="mailto:' . $email . '" class="color0 no-underline">' . $email . '</a>';
$contactData[] = '<a href="' . $homepage->httpUrl . '" target="_blank" class="color0 no-underline">' . $homepage->httpUrl . '</a>';

// get the rendered content of the newsletter
$html = wireRenderFile('_newsletter-content.php', array(
    'allowCache'       => false,
    'newsletter_title' => 'ProcessWire Newsletter',
    'homepage'         => wire('pages')->get(1),
    'logo'             => $logo,
    'images'           => $images,
    'email'            => $email,
    'facebookUrl'      => 'https://www.facebook.com/processwire/',
    'twitterUrl'       => 'https://twitter.com/processwire',
    'contactLine'      => implode('&nbsp;•&nbsp;', $contactData)
));

// set up html/css for Emogrifier
$emogrifier->setHtml($html);
$emogrifier->setCss($css);


if ($config->ajax) {

    // if this is an ajax call

    if (!isset($_POST['nid']) || empty($_POST['nid'])) {
        return false;
    }

    $nid = $_POST['nid'];

    $newsletter = wire('pages')->get($nid);

    if (!$newsletter->id) {
        return false;
    }

    $html = $emogrifier->emogrifyBodyContent();

    // detect mode
    $testMode = isset($_POST['test_email']) ? true : false;

    if ($testMode) {
        $subscribers = wire('input')->post('test_email');
        if (strpos($subscribers, ',') !== false) {
            $subscribers = explode(',', $subscribers);
        }

    } else {
        $subscribers = $pages->find('template=subscriber');
        $subscribers = $subscribers->explode('email');
    }

    if (is_array($subscribers)) {
        $subscribers = array_map('trim', $subscribers);
    }

    $mail = WireMail();

    $mail->to($subscribers);
    $mail->from('Admin' . ' <noreply@mysite.com>');
    $mail->subject($newsletter->title);
    $mail->bodyHTML($html);

    // uncomment this if you use MailGun and need to add tags
    // $mail->addTag('newsletter');

    $mail->send();

    echo json_encode(count($subscribers));
    $this->halt();

} else {

    // regular page load: echo page to view in browser & to preview
    echo $emogrifier->emogrify();
}


// convert relative urls to absolute (eg. image src)
function absoluteUrl($html) {

    $homepage = wire('pages')->get(1);

    $replacements = array(
        '="' . $homepage->httpUrl . 'site/',
        "='" . $homepage->httpUrl . "site/"
    );

    return str_replace(array('="/site/', "='/site/"), $replacements, $html);
}