$(document).ready(function () {

    //if ($('#newsletter_send').length) {
    if (true) {

        var hasFormChanged = false,
            sendNewsletterButton = $('#newsletter_send'),
            newsletterTestButton = $('#newsletter_test'),
            newsletterTestEmailInput = $('input#Inputfield_newsletter_test_email');

        $(sendNewsletterButton).find('span').removeClass();
        $(newsletterTestButton).find('span').removeClass();
        sendNewsletterButton.button();
        newsletterTestButton.button();

        function setButtonDisable($btn) {
            $btn.addClass('ui-button-disabled ui-state-disabled');
            $btn.parent().attr('style', 'cursor: not-allowed !important');
            $btn.attr('style', 'cursor: not-allowed !important');
        }

        function setButtonEnable($btn) {
            $btn.removeClass('ui-button-disabled ui-state-disabled');
            $btn.parent().attr('style', 'cursor: pointer;');
            $btn.attr('style', 'cursor: pointer;');
        }

        function setButtonText($btn, $txt, selector) {
            selector = selector ? selector : '.ui-button-text span';
            $btn.find(selector).text($txt);
        }

        function prependButton($btn, $icon) {
            $btn.children('span').prepend($icon + '&nbsp;');
        }

        $('#ProcessPageEdit').on('change', function (e) {

            if ($('.ProcessPageEditContent').length) {

                var target = e.target || e.srcElement;

                // do not process Test button
                if ($(target).attr('id') == 'Inputfield_newsletter_test_email') {
                    return false;
                }

                setButtonDisable(sendNewsletterButton);
                setButtonText(sendNewsletterButton, 'Newsletter content changed, please save first!');

                setButtonDisable(newsletterTestButton);
                setButtonText(newsletterTestButton, 'Newsletter content changed, please save first!');

                hasFormChanged = true;
            }
        });

        // $('#Inputfield_newsletter_test_email').on('click', function (e) {
        //     hasFormChanged = false;
        // });

        sendNewsletterButton.on('click', function (e) {

            if ($(this).hasClass('ui-button-disabled')) {
                return false;
            }

            if (hasFormChanged) {
                alert('Newsletter content changed, please save first!');
                return false;
            }

            if (!confirm('Are you sure you would like to send?')) {
                return false;
            }

            setButtonDisable(sendNewsletterButton);
            setButtonText(sendNewsletterButton, 'Sending...');
            prependButton(sendNewsletterButton, '<i class="fa fa-spin fa-spinner"></i>');

            e.preventDefault();

            var values = {
                'nid': $(this).attr('data-nid'),
                'redirect': $(this).attr('data-redirect')
            };

            $.ajax({
                url: $(this).parents('a').attr('href'),
                type: "post",
                data: values,
                success: function (response) {
                    alert('Newsletter successfully sent to ' + response + ' subscribers.');

                    // setButtonEnable(sendNewsletterButton);
                    setButtonText(sendNewsletterButton, 'Successful send!', 'span.ui-button-text');
                    newsletterTestButton.find('i').remove();

                    //window.location.reload();
                    // window.location.href = '/admin/page/?open=' + values.redirect;
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log(textStatus, errorThrown);
                }

            });

            return false;
        });


        newsletterTestEmailInput.on('change keyup', function (e) {

            var val = newsletterTestEmailInput.val();

            // todo validate multiple
            // only check for "@" existence because value may contain multiple emails
            if (val == "" || val.indexOf("@") === -1) {
                setButtonDisable(newsletterTestButton);
            } else {
                setButtonEnable(newsletterTestButton);
            }
        });


        // set Page view mode to panel
        $('body.ProcessPageEdit-template-newsletter a#_ProcessPageEditView').attr('data-action', 'panel');


        newsletterTestButton.on('click', function (e) {

            var testEmails = newsletterTestEmailInput.val();

            if (testEmails === "") {
                return false;
            }

            if ($(this).hasClass('ui-button-disabled')) {
                return false;
            }

            if (hasFormChanged) {
                alert('Newsletter content changed, please save first!');
                return false;
            }

            setButtonDisable($(this));
            setButtonText($(this), 'Sending...');
            prependButton($(this), '<i class="fa fa-spin fa-spinner"></i>');

            e.preventDefault();

            var values = {
                'nid': $(this).attr('data-nid'),
                'test_email': testEmails
            };

            $.ajax({
                url: $(this).attr('data-target'),
                type: "post",
                data: values,
                success: function (response) {

                    setButtonText(newsletterTestButton, 'Successful send!', 'span.ui-button-text');
                    setButtonEnable(newsletterTestButton);
                    newsletterTestButton.find('i').remove();

                    setTimeout(function () {
                        if (newsletterTestButton.length) {
                            setButtonText(newsletterTestButton, 'Send test', 'span.ui-button-text');
                        }
                    }, 5000);

                    //window.location.reload();
                    // window.location.href = '/admin/page/?open=' + values.redirect;
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log(textStatus, errorThrown);
                }

            });

            return false;
        })

    }

});