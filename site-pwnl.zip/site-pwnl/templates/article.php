<?php
include_once('./basic-page.php');