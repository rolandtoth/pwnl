<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php echo $page->title; ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo $config->urls->templates ?>styles/newsletter.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="format-detection" content="telephone=no" />
    <!--[if !mso]><!-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!--<![endif]-->
    <meta name="robots" content="noindex, nofollow" />
</head>
<body>

<?php if ($page->excerpt) { ?>
<span class="preheader"><?php echo $page->excerpt; ?></span>
<?php } ?>

<table cellpadding="0" cellspacing="0" border="0" width="100%" class="bg-color4">
    <tr>
        <td align="center" class="bg-color4">
            <table cellpadding="0" cellspacing="0" border="0" width="600" class="bg-color4">
                <tr>
                    <td>
                        <!-- VIEW ONLINE LINK-->
                        <table cellpadding="0" cellspacing="0" border="0" width="600" class="mb0">
                            <tr>
                                <td valign="middle" align="center" class="p1 pt05 pb05">
                                    <p class="text-center text-small m0">
                                        Click
                                        <a href="<?php echo $page->httpUrl; ?>" class="link underline" target="_blank">here</a> the view in browser
                                    </p>
                                </td>
                            </tr>
                        </table>

                        <table cellpadding="0" cellspacing="0" border="0" width="600" bgcolor="#ffffff" class="mb0">
                            <tr>
                                <td class="p1 pb0 text-center">
                                    <a href="<?php echo $homepage->httpUrl; ?>" target="_blank" class="inline-block">
                                        <img src="<?php echo $logo->httpUrl; ?>" alt="" width="<?php echo $logo->width; ?>" height="<?php echo $logo->height; ?>" border="0" />
                                    </a>

                                    <h3 class="text-center mt05 mb05 uppercase">
                                        <?php echo $newsletter_title; ?>
                                    </h3>

                                    <p class="text-center mb05">
                                        <?php echo $contactLine; ?>
                                    </p>
                                </td>
                            </tr>
                        </table>

                        <table cellpadding="0" cellspacing="0" border="0" width="600" bgcolor="#ffffff" class="mb05">
                            <?php if ($page->featured_image) { ?>
                                <?php $featured_image = $page->featured_image->width(600); ?>
                                <tr>
                                    <td>
                                        <table cellpadding="0" cellspacing="0" border="0" width="600">
                                            <tr>
                                                <td>
                                                    <img src="<?php echo $featured_image->httpUrl; ?>" alt="" width="<?php echo $featured_image->width; ?>" height="<?php echo $featured_image->height; ?>" border="0" />
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            <?php } ?>
                            <tr>
                                <td align="center" class="content-block">
                                    <table cellpadding="0" cellspacing="0" border="0" width="560">
                                        <tr>
                                            <td>
                                                <h1 class="mb05 color3">
                                                    <?php echo $page->title; ?>
                                                </h1>
                                            </td>
                                        </tr>
                                        <?php if ($page->body) { ?>
                                            <tr>
                                                <td>
                                                    <?php echo $page->body; ?>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </table>
                                </td>
                            </tr>
                        </table>

                        <?php if ($page->article_ref->count()) { ?>
                            <?php foreach ($page->article_ref as $article) { ?>
                                <table cellpadding="0" cellspacing="0" border="0" width="600" bgcolor="#ffffff" class="mb05">
                                    <?php if ($article->featured_image) { ?>
                                        <?php $featured_image = $article->featured_image->width(552); ?>
                                        <tr>
                                            <td align="center">
                                                <table cellpadding="0" cellspacing="0" border="0" width="552">
                                                    <tr>
                                                        <td>
                                                            <a href="<?php echo $article->httpUrl; ?>" target="_blank">
                                                                <img src="<?php echo $featured_image->httpUrl; ?>" alt="" width="<?php echo $featured_image->width; ?>" height="<?php echo $featured_image->height; ?>" border="0" class="m1 mb0" />
                                                            </a>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td align="center" class="content-block">
                                            <table cellpadding="0" cellspacing="0" border="0" width="552">
                                                <tr>
                                                    <td>
                                                        <h1 class="mb05 color3">
                                                            <a href="<?php echo $article->httpUrl; ?>" target="_blank">
                                                                <?php echo $article->title; ?>
                                                            </a>
                                                        </h1>
                                                    </td>
                                                </tr>
                                                <?php if ($article->body) { ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo $article->body; ?>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                                <tr>
                                                    <td>
                                                        <p>
                                                            <a href="<?php echo $article->httpUrl; ?>" class="button" target="_blank">Read more</a>
                                                        </p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            <?php } ?>
                        <?php } ?>

                        <table cellpadding="0" cellspacing="0" border="0" width="600" bgcolor="#ffffff" class="mb05 footer">
                            <tr>
                                <td class="p1">

                                    <p class="text-center">
                                        <?php echo $contactLine; ?>
                                    </p>

                                    <p class="text-center social mb0">
                                        <a href="<?php echo $facebookUrl; ?>" target="_blank" class="no-underline inline-block">
                                            <img src="<?php echo $images . 'dark/facebook.jpg'; ?>" width="24" height="24" alt="Facebook" class="inline-block">
                                        </a>
                                        <a href="<?php echo $twitterUrl; ?>" target="_blank" class="no-underline inline-block">
                                            <img src="<?php echo $images . 'dark/twitter.jpg'; ?>" width="24" height="24" alt="Twitter" class="inline-block">
                                        </a>
                                        <a href="<?php echo $homepage->httpUrl; ?>#map" target="_blank" class="no-underline inline-block">
                                            <img src="<?php echo $images . 'dark/location.jpg'; ?>" width="24" height="24" alt="Address" class="inline-block">
                                        </a>
                                        <a href="mailto:<?php echo $email; ?>" target="_blank" class="no-underline inline-block">
                                            <img src="<?php echo $images . 'dark/email.jpg'; ?>" width="24" height="24" alt="Email" class="inline-block">
                                        </a>
                                    </p>
                                </td>
                            </tr>
                        </table>

                        <!-- FOOTER-->
                        <table cellpadding="0" cellspacing="0" border="0" width="600" class="bg-color4">
                            <tr>
                                <td>
                                    <p class="text-center">
                                        <a class="color0 text-muted text-small" href="<?php echo $page->httpUrl; ?>#unsubscribe">Unsubscribe</a>
                                        <span class="color0 text-muted text-small">&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</span>
                                        <a href="<?php echo $page->httpUrl; ?>" class="color0 text-muted text-small" target="_blank">View in browser</a>
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

</body>
</html>