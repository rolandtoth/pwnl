<?php

// just add some info here
$page->body = '<p>This is a tutorial for a basic newsletter setup in ProcessWire CMS.</p>';

include("./basic-page.php");
